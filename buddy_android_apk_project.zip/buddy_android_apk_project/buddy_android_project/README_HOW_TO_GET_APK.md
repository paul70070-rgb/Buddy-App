# Buddy • Signed Android APK & Google Play Store Publishing Guide

This package includes:
- Clean, single-screen-per-tab mobile UI (`app/src/main/assets/index.html`)
- Pre-generated **Release Signing Keystore** (`app/buddy-release-key.jks`)
- Automated Cloud Builder (`.github/workflows/build-apk.yml`) that outputs **both**:
  1. `app-release.apk` (to install directly on your Android phone)
  2. `app-release.aab` (to upload to the Google Play Console)

---

## Part 1: Get Your Installable `.apk` File (In 2 Minutes, No PC Needed)
1. Sign in to [GitHub](https://github.com/new) and create a new repository (e.g. `buddy-app`).
2. Upload the contents of this `buddy_android_project` folder.
3. Open the **Actions** tab -> select **Build Signed Buddy APK & Google Play AAB** -> click **Run workflow**.
4. Download **`Buddy-Installable-APK`** (`app-release.apk`) and tap it on your Android phone to install!
*(Or in Android Studio: click **Build → Generate Signed Bundle / APK** using `app/buddy-release-key.jks`, password `BuddyLove2026`).*

---

## Part 2: How to Put Buddy on the Google Play Store
1. **Create a Google Play Console Account:** Go to [Google Play Console](https://play.google.com/console/signup) and register a personal developer account ($25 one-time fee).
2. **Create App:** Click **Create app**, name it **Buddy**, choose **App**, and select **Free**.
3. **Complete Store Listing:**
   - Upload the included icon (`app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`).
   - Fill out the Privacy Policy & Data Safety form (declare Microphone usage for voice commands; all personal goals/diet logs stay in local on-device storage).
4. **Upload the `.aab` File:**
   - Go to **Testing → Internal testing** (or **Production**), click **Create new release**, and upload `app-release.aab` (from the `Buddy-Google-Play-Store-AAB` download).
   - Roll out the release to install Buddy directly from the Google Play Store!
